module.exports = {
  client: 'mysql',
  version:'5.7',
  connection: {
    user: 'root',
    password: '1234',
    database: 'kickstarter'
  }
}